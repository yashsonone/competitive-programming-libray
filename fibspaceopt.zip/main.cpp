/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<bits/stdc++.h>
using namespace std;
int fibSpaceOpt(int n){
    if(n<=2){
        return n;
    }
    int a =0;
    int b =1;
    int c = a+b;
    for(int i=2;i<=n;i++){
        c = a+b;
        a = b;
        b = c;
    }
    return c;
}
int main()
{
    int n;
    cin>>n;
    cout<<fibSpaceOpt(n);

    return 0;
}
