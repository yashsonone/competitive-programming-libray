/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<bits/stdc++.h>
using namespace std;
int minCoins(int n,int coins[],int T,int dp[]){
    if(n==0){
        return 0;
    }
    if(dp[n]!=0){
        return dp[n];
    }
    int ans = INT_MAX;
 
    for(int i=0;i<T;i++){
         if(n-coins[i] >= 0){
        int subproblem = minCoins(n-coins[i],coins,T,dp);
        ans = min(ans,subproblem + 1);
    }
    }
    dp[n] = ans;
    return dp[n];
}

int main()
{
    int n;
    cin>>n;
    int T;
    cin>>T;
    int coins[T];
    int dp[100] = {0};
    for(int i=0;i<T;i++){
        cin>>coins[i];
    }
    cout<<minCoins(n,coins,T,dp);

    return 0;
}
