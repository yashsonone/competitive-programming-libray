/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
int maxSum(int a[],int n){
    int dp[100] = {0};
     dp[0] = a[0]>0?a[0]:0;
    int max_so_far = 0;
    for(int i=1;i<n;i++){
        dp[i] = dp[i-1] + a[i];
        if(dp[i]<0){
            dp[i] = 0;
        }
        max_so_far = max(dp[i],max_so_far);
        
    }
    return max_so_far;
    
}

int main()
{
   int n;
   std::cin >> n;
   int a[n];
   for(int i=0;i<n;i++){
       cin>>a[i];
   }
   cout<<maxSum(a,n);

    return 0;
}
