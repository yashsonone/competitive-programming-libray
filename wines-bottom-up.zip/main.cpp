/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
int f(int wines[],int i,int j,int y,int dp[][100]){
    if(i>j){
        return 0;
    }
    if(dp[i][j] != 0){
        return dp[i][j];
    }
    int op1 = wines[i]*y + f(wines,i+1,j,y+1,dp);
    int op2 = wines[j]*y + f(wines,i,j-1,y+1,dp);
    return dp[i][j] = max(op1,op2);
    
    
}

int main()
{
    int n;
    cin>>n;
    int wines[n];
    for(int i=0;i<n;i++){
    cin>>wines[i];
    }
    int y = 1;
    int dp[100][100] = {0};
    cout<<f(wines,0,n-1,y,dp);

    return 0;
}
