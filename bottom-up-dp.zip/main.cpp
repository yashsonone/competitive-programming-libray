/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int fibBu(int n){
    int dp[100] = {0};
    if(n<=1){
        return n;
    }
    if(dp[n] != 0){
        return dp[n];
    }
    int ans = fibBu(n-1)*fibBu(n-2);
    return dp[n] = ans;
}

int main()
{
    printf("Hello World");
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin>>n;
    cout<<fibBu(n);
        return 0;
}
