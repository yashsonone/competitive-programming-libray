/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int fib(int n,int dp[]){
    if(n<=1){
        return n;
    }
        int ans;
        if(dp[n]!=0){
            return dp[n];
        }
        ans = fib(n-1,dp)+fib(n-2,dp);
        return dp[n] = ans;
  
}

int main()
{
    int n;
    cin>>n;
    int dp[n] = {0};
    cout<<fib(n,dp);
    

    return 0;
}
